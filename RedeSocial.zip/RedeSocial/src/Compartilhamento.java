public interface Compartilhamento {
    void compartilhar();
}
