public interface VideoConferencia {
    void fazStreaming();
}
