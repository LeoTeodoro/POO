public interface LutarComArmas{
    public void atacar(Personagem alvo);
}
