public class Arma {
    private String name;
    private int dano;

    public Arma(String name, int dano) {
        this.name = name;
        this.dano = dano;
    }

    public int getDano() {
        return dano;
    }
}
